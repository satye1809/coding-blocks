setTimeout(function(){
    console.log("1 SECOND HAS PASSED!")
},3000)