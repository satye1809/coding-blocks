function fun(){
    console.log(global===this)
}