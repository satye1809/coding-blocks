let obj={
    a:1,
    b:"hello",
    c:{
        c1:123,
        c2:"hello2"
    },
    d:[1,2,3]
}

obj.newProp = "123";

console.log(obj.newProp);