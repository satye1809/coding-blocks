let a = 1;

setTimeout(function () {
    console.log("2")
},3000)


while (a<10000) {
    a++;
    console.log("1")
}

