const obj ={
    name:"Abhishek",
    profession:"Teacher"
}

module.exports=obj;