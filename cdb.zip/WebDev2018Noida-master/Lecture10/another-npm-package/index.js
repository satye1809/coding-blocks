const pkg=require('../sample-npm-package');

console.log(pkg.name);
console.log(pkg.profession);