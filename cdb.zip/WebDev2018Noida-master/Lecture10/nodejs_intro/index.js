const lib= require('./lib');

console.log(lib.square(10));
console.log(lib.addition(2,3));