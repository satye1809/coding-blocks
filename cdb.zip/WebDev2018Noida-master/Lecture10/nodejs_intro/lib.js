function square(x) {
    return x * x;
}


function addition(x, y) {
    return x + y;
}

module.exports = {
    square,
    addition
}