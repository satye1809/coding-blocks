const app = require('./server');

app.listen(8080,function () {
    console.log("The server is up and running at 8080!")
})