//This is a single line comment

/*
This is a multi-line comment
 */

// var a=1;
// console.log(a);
// a='abcd';
// console.log(a);


//let keyword

// let b=1;
// console.log(b);
// b='defg'
// console.log(b);


//const keyword
//reassignment of variable is not allowed in const

// const myVar=1;
// console.log(myVar);
// myVar++;
// console.log(myVar);

//typeof

let m=1;
console.log(typeof m);
m='abcd';
console.log(typeof m);


// Reference error
//console.log(n);

