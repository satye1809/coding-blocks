let str="Abhishek";

//Searching the word
console.log(str.length);

let pos=str.indexOf("hi");
console.log(pos);

//returns -1 when not found
let pos2=str.lastIndexOf("sm");
console.log(pos2);


//slice
console.log(str)

console.log(str.slice(0,4));

console.log(str);


//substring
console.log(str.substring(1,5));

//substr
console.log(str.substr(1,5));
